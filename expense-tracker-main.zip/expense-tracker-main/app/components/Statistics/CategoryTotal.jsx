export const CategoryTotal = () => {
  return <div>CategoryTotal</div>;
};
