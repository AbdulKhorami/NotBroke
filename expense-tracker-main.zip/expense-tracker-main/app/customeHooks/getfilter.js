import React, { useState } from 'react'

function getfilter() {
    
       const [dateRange,setDateRange] = useState(null)
       const [filterData ,setFilterData] = useState({
                 from:0,
                 to:0,            
       })
       const [category,setCategory] = useState(null)


    
}

export default getfilter