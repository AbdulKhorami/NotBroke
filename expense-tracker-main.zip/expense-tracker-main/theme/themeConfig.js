const theme = {
  token: {
    fontSize: 16,
    colorPrimary: '#219653',
  },
};

export default theme;
